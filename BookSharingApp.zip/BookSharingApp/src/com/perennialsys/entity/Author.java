package com.perennialsys.entity;

public class Author {
    private int id;
    private String name;
    private String email;

}
