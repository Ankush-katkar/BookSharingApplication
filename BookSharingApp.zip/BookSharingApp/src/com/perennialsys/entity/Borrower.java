package com.perennialsys.entity;

import java.util.ArrayList;

public class Borrower extends User {


}
